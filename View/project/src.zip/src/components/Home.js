import React from 'react';

export default function Home({ users, loading, error, handleSubmit, input, setInput }) {
    return (
        <div>
            <h1>Trang Chủ</h1>
            {/* copy nội dung form và danh sách user bạn đã làm */}
        </div>
    );
}