// =====================================
// UNIFIED ListeningTestDisplay.js - Layout giống Reading
// =====================================

import React, {useState, useEffect, useRef, useMemo, useCallback} from 'react';
import './ListeningTestDisplay.css';

const ListeningTestDisplay = ({
                                  test,
                                  audioList,
                                  questions,
                                  userAnswers,
                                  onAnswerChange,
                                  isSubmitted = false,
                                  timer,
                                  onSubmit,
                                  submitting = false
                              }) => {
    const [currentAudioIndex, setCurrentAudioIndex] = useState(0);
    const [isPlaying, setIsPlaying] = useState(false);
    const [currentTime, setCurrentTime] = useState(0);
    const [duration, setDuration] = useState(0);
    const [volume, setVolume] = useState(1);
    const [audioReady, setAudioReady] = useState(false);
    const [audioError, setAudioError] = useState(null);
    const [loadingAudio, setLoadingAudio] = useState(false);
    const [expandedSections, setExpandedSections] = useState(new Set());

    const audioRef = useRef();
    const currentAudio = audioList && audioList[currentAudioIndex];

    // Auto-expand all sections initially
    useEffect(() => {
        if (questions && questions.length > 0) {
            const questionGroups = processQuestions;
            const allGroupIds = questionGroups.map((_, index) => index);
            setExpandedSections(new Set(allGroupIds));
        }
    }, [questions]);

    // Enhanced audio source detection
    const getValidAudioSource = (audioData) => {
        if (!audioData) return null;

        if (audioData.audioBase64) {
            const base64Data = audioData.audioBase64;
            if (base64Data.startsWith('data:')) {
                return base64Data;
            } else {
                const mimeType = audioData.mimeType || 'audio/mpeg';
                return `data:${mimeType};base64,${base64Data}`;
            }
        }

        if (audioData.base64Data) {
            const base64Data = audioData.base64Data;
            if (base64Data.startsWith('data:')) {
                return base64Data;
            } else {
                const mimeType = audioData.mimeType || 'audio/mpeg';
                return `data:${mimeType};base64,${base64Data}`;
            }
        }

        if (audioData.fileUrl) return audioData.fileUrl;
        if (audioData.filePath) {
            return audioData.filePath.startsWith('http')
                ? audioData.filePath
                : `${window.location.origin}/api${audioData.filePath}`;
        }

        return null;
    };

    // Process questions into logical groups
    const processQuestions = useMemo(() => {
        if (!questions || questions.length === 0) return [];

        const groups = {};

        questions.forEach((question, idx) => {
            const audioId = question.audioId || question.audio_id || null;
            const instructions = question.questionSetInstructions || question.question_set_instructions || '';
            const questionType = question.questionType || question.question_type || 'FILL_IN_THE_BLANK';
            const context = question.context || '';
            const orderInTest = question.orderInTest || question.order_in_test || (idx + 1);

            // Detect question sub-type for better UI
            let subType = questionType;
            let displayName = questionType.replace(/_/g, ' ');

            if (questionType === 'FILL_IN_THE_BLANK' && context) {
                try {
                    const parsed = JSON.parse(context);
                    if (parsed.type === 'ielts_table_completion') {
                        subType = 'TABLE_COMPLETION_JSON';
                        displayName = 'Table Completion';
                    }
                } catch (e) {
                    if (context.includes('|') && context.split('\n').filter(line => line.includes('|')).length >= 2) {
                        subType = 'TABLE_COMPLETION';
                        displayName = 'Table Completion';
                    } else if (context.toLowerCase().includes('notes') || context.toLowerCase().includes('note')) {
                        subType = 'NOTE_COMPLETION';
                        displayName = 'Note Completion';
                    } else if (context.toLowerCase().includes('form')) {
                        subType = 'FORM_FILLING';
                        displayName = 'Form Filling';
                    } else if (context.toLowerCase().includes('plan') || context.toLowerCase().includes('map')) {
                        subType = 'PLAN_MAP_COMPLETION';
                        displayName = 'Plan/Map Completion';
                    } else {
                        subType = 'SENTENCE_COMPLETION';
                        displayName = 'Sentence Completion';
                    }
                }
            } else if (questionType === 'MCQ') {
                displayName = 'Multiple Choice';
            } else if (questionType === 'MATCHING') {
                displayName = 'Matching';
            } else if (questionType === 'SHORT_ANSWER') {
                displayName = 'Short Answer';
            }

            const contextKey = context ? context.substring(0, 100).replace(/[^a-zA-Z0-9]/g, '_') : 'no_context';
            const instructionsKey = instructions ? instructions.substring(0, 50).replace(/[^a-zA-Z0-9]/g, '_') : 'default';
            const key = `${audioId}_${subType}_${contextKey}_${instructionsKey}`;

            if (!groups[key]) {
                groups[key] = {
                    audioId: audioId,
                    questionType: questionType,
                    subType: subType,
                    displayName: displayName,
                    instructions: instructions,
                    context: context,
                    requiresContext: !!(context && context.trim()),
                    questions: []
                };
            }

            groups[key].questions.push({
                id: question.id || question.question_id,
                questionText: question.questionText || question.question_text || '',
                questionNumber: orderInTest,
                questionType: questionType,
                correctAnswer: question.correctAnswer || question.correct_answer || '',
                options: question.options || [],
                alternativeAnswers: question.alternativeAnswers || question.alternative_answers || '',
                wordLimit: question.wordLimit || question.word_limit,
                audioId: audioId,
                context: context,
                instructions: instructions
            });
        });

        return Object.values(groups)
            .map(group => ({
                ...group,
                questions: group.questions.sort((a, b) => (a.questionNumber || 0) - (b.questionNumber || 0))
            }))
            .sort((a, b) => {
                const audioDiff = (a.audioId || 0) - (b.audioId || 0);
                if (audioDiff !== 0) return audioDiff;
                return (a.questions[0]?.questionNumber || 0) - (b.questions[0]?.questionNumber || 0);
            });
    }, [questions]);

    // Enhanced JSON table renderer
    const renderJSONTable = (context, group) => {
        try {
            const parsed = JSON.parse(context);
            if (parsed.type !== 'ielts_table_completion') return null;

            const { title, data, questions: tableQuestions } = parsed;

            return (
                <div className="table-container">
                    {title && <h4 className="table-title">{title}</h4>}
                    <div className="table-wrapper">
                        <table className="completion-table">
                            {data && data.length > 0 && (
                                <>
                                    <thead>
                                    <tr>
                                        {data[0].map((header, colIndex) => (
                                            <th key={colIndex} className="table-header">
                                                {header}
                                            </th>
                                        ))}
                                    </tr>
                                    </thead>
                                    <tbody>
                                    {data.slice(1).map((row, rowIndex) => (
                                        <tr key={rowIndex}>
                                            {row.map((cell, colIndex) => {
                                                const questionMatch = cell.match(/___(\d+)___/);

                                                if (questionMatch) {
                                                    const questionNumber = parseInt(questionMatch[1]);
                                                    const question = group.questions.find(q => q.questionNumber === questionNumber);

                                                    return (
                                                        <td key={colIndex} className="question-cell">
                                                            <div className="question-input-wrapper">
                                                                <span className="question-number">{questionNumber}</span>
                                                                <input
                                                                    type="text"
                                                                    className="table-input"
                                                                    placeholder={`Answer ${questionNumber}`}
                                                                    value={userAnswers[question?.id] || ''}
                                                                    onChange={(e) => question && onAnswerChange(question.id, e.target.value)}
                                                                    disabled={isSubmitted}
                                                                    maxLength={50}
                                                                />
                                                            </div>
                                                        </td>
                                                    );
                                                } else {
                                                    return (
                                                        <td key={colIndex} className="data-cell">
                                                            {cell}
                                                        </td>
                                                    );
                                                }
                                            })}
                                        </tr>
                                    ))}
                                    </tbody>
                                </>
                            )}
                        </table>
                    </div>
                </div>
            );
        } catch (e) {
            return null;
        }
    };

    // Enhanced markdown table renderer
    const renderMarkdownTable = (context, group) => {
        const lines = context.split('\n').filter(line => line.trim());
        let title = '';
        let tableLines = [];

        for (let i = 0; i < lines.length; i++) {
            const line = lines[i].trim();
            if (line && !line.includes('|') && !line.includes('-')) {
                if (tableLines.length === 0) title = line;
            } else if (line.includes('|') && !line.includes('---')) {
                const cells = line.split('|').map(cell => cell.trim()).filter(cell => cell !== '');
                if (cells.length > 0) tableLines.push(cells);
            }
        }

        if (tableLines.length === 0) return null;

        return (
            <div className="table-container">
                {title && <h4 className="table-title">{title}</h4>}
                <div className="table-wrapper">
                    <table className="completion-table">
                        <thead>
                        <tr>
                            {tableLines[0]?.map((header, colIndex) => (
                                <th key={colIndex} className="table-header">
                                    {header}
                                </th>
                            ))}
                        </tr>
                        </thead>
                        <tbody>
                        {tableLines.slice(1).map((row, rowIndex) => (
                            <tr key={rowIndex}>
                                {row.map((cell, colIndex) => {
                                    const questionMatch = cell.match(/___(\d+)___/);

                                    if (questionMatch) {
                                        const questionNumber = parseInt(questionMatch[1]);
                                        const question = group.questions.find(q => q.questionNumber === questionNumber);

                                        return (
                                            <td key={colIndex} className="question-cell">
                                                <div className="question-input-wrapper">
                                                    <span className="question-number">{questionNumber}</span>
                                                    <input
                                                        type="text"
                                                        className="table-input"
                                                        placeholder={`Answer ${questionNumber}`}
                                                        value={userAnswers[question?.id] || ''}
                                                        onChange={(e) => question && onAnswerChange(question.id, e.target.value)}
                                                        disabled={isSubmitted}
                                                        maxLength={50}
                                                    />
                                                </div>
                                            </td>
                                        );
                                    } else {
                                        return (
                                            <td key={colIndex} className="data-cell">
                                                {cell}
                                            </td>
                                        );
                                    }
                                })}
                            </tr>
                        ))}
                        </tbody>
                    </table>
                </div>
            </div>
        );
    };

    // Enhanced context renderer for non-table types
    const renderContextWithInputs = (context, group) => {
        if (!context || !context.trim()) return null;

        const parts = context.split(/(\s*___\d+___\s*)/);

        return (
            <div className="context-container">
                {parts.map((part, index) => {
                    const blankMatch = part.match(/___(\d+)___/);

                    if (blankMatch) {
                        const questionNum = parseInt(blankMatch[1]);
                        const question = group.questions.find(q => q.questionNumber === questionNum);

                        return (
                            <span key={index} className="inline-blank">
                                <span className="question-number">{questionNum}</span>
                                <input
                                    type="text"
                                    className="inline-input"
                                    placeholder={`${questionNum}`}
                                    value={userAnswers[question?.id] || ''}
                                    onChange={(e) => question && onAnswerChange(question.id, e.target.value)}
                                    disabled={isSubmitted}
                                    maxLength={50}
                                />
                            </span>
                        );
                    }

                    return <span key={index}>{part}</span>;
                })}
            </div>
        );
    };

    // Enhanced question input renderer
    const renderQuestionInput = (question, questionType) => {
        switch (questionType) {
            case 'MCQ':
                const options = Array.isArray(question.options) ? question.options : [];
                return (
                    <div className="mcq-options">
                        {['A', 'B', 'C', 'D'].map((letter, idx) => (
                            <div key={letter} className="mcq-option">
                                <input
                                    type="radio"
                                    id={`question-${question.id}-option-${idx}`}
                                    name={`question_${question.id}`}
                                    value={letter}
                                    checked={userAnswers[question.id] === letter}
                                    onChange={(e) => onAnswerChange(question.id, e.target.value)}
                                    disabled={isSubmitted}
                                />
                                <label htmlFor={`question-${question.id}-option-${idx}`}>
                                    {letter}. {options[idx] || ''}
                                </label>
                            </div>
                        ))}
                    </div>
                );

            case 'MATCHING':
                return (
                    <div className="answer-input-container">
                        <input
                            type="text"
                            className="answer-input"
                            placeholder="Enter letter (A, B, C, etc.)"
                            value={userAnswers[question.id] || ''}
                            onChange={(e) => onAnswerChange(question.id, e.target.value)}
                            disabled={isSubmitted}
                        />
                        <div className="input-hint">Enter the matching letter</div>
                    </div>
                );

            case 'SHORT_ANSWER':
                return (
                    <div className="answer-input-container">
                        <input
                            type="text"
                            className="answer-input"
                            placeholder="Enter your answer"
                            value={userAnswers[question.id] || ''}
                            onChange={(e) => onAnswerChange(question.id, e.target.value)}
                            disabled={isSubmitted}
                        />
                        <div className="input-hint">Write NO MORE THAN THREE WORDS</div>
                    </div>
                );

            case 'TRUE_FALSE_NOT_GIVEN':
                return (
                    <div className="true-false-options">
                        {['TRUE', 'FALSE', 'NOT_GIVEN'].map((option) => (
                            <div key={option} className="true-false-option">
                                <input
                                    type="radio"
                                    id={`question-${question.id}-option-${option}`}
                                    name={`question_${question.id}`}
                                    value={option}
                                    checked={userAnswers[question.id] === option}
                                    onChange={(e) => onAnswerChange(question.id, e.target.value)}
                                    disabled={isSubmitted}
                                />
                                <label htmlFor={`question-${question.id}-option-${option}`}>
                                    {option === 'TRUE' ? 'True' :
                                        option === 'FALSE' ? 'False' : 'Not Given'}
                                </label>
                            </div>
                        ))}
                    </div>
                );

            default:
                return (
                    <input
                        type="text"
                        className="answer-input"
                        placeholder="Enter your answer"
                        value={userAnswers[question.id] || ''}
                        onChange={(e) => onAnswerChange(question.id, e.target.value)}
                        disabled={isSubmitted}
                    />
                );
        }
    };

    // Audio loading and control logic
    useEffect(() => {
        if (!currentAudio || !audioRef.current) return;

        const audio = audioRef.current;
        setAudioReady(false);
        setAudioError(null);
        setLoadingAudio(true);
        setIsPlaying(false);
        setCurrentTime(0);
        setDuration(0);

        const audioSrc = getValidAudioSource(currentAudio);
        if (!audioSrc) {
            setLoadingAudio(false);
            setAudioError('No valid audio source available');
            return;
        }

        const loadTimeout = setTimeout(() => {
            setLoadingAudio(false);
            setAudioError('Audio took too long to load.');
        }, 15000);

        const handleCanPlay = () => {
            clearTimeout(loadTimeout);
            setLoadingAudio(false);
            setAudioReady(true);
            setAudioError(null);
        };

        const handleLoadedMetadata = () => {
            if (audio.duration && !isNaN(audio.duration)) {
                setDuration(audio.duration);
            }
        };

        const handleError = () => {
            clearTimeout(loadTimeout);
            setLoadingAudio(false);
            setAudioReady(false);
            setAudioError('Unable to load audio.');
        };

        const handleTimeUpdate = () => {
            if (audio.currentTime) {
                setCurrentTime(audio.currentTime);
            }
        };

        const handlePlay = () => setIsPlaying(true);
        const handlePause = () => setIsPlaying(false);
        const handleEnded = () => setIsPlaying(false);

        audio.addEventListener('canplay', handleCanPlay);
        audio.addEventListener('loadedmetadata', handleLoadedMetadata);
        audio.addEventListener('error', handleError);
        audio.addEventListener('timeupdate', handleTimeUpdate);
        audio.addEventListener('play', handlePlay);
        audio.addEventListener('pause', handlePause);
        audio.addEventListener('ended', handleEnded);

        audio.src = audioSrc;
        audio.load();

        return () => {
            clearTimeout(loadTimeout);
            audio.removeEventListener('canplay', handleCanPlay);
            audio.removeEventListener('loadedmetadata', handleLoadedMetadata);
            audio.removeEventListener('error', handleError);
            audio.removeEventListener('timeupdate', handleTimeUpdate);
            audio.removeEventListener('play', handlePlay);
            audio.removeEventListener('pause', handlePause);
            audio.removeEventListener('ended', handleEnded);

            if (audioSrc && audioSrc.startsWith('blob:')) {
                URL.revokeObjectURL(audioSrc);
            }
        };
    }, [currentAudio]);

    const togglePlay = async () => {
        if (!audioRef.current || loadingAudio || audioError || !audioReady) return;

        try {
            if (isPlaying) {
                audioRef.current.pause();
            } else {
                await audioRef.current.play();
            }
        } catch (error) {
            setAudioError('Unable to play audio.');
        }
    };

    const handleProgressClick = (e) => {
        if (!audioRef.current || !audioReady || !duration) return;

        const progressBar = e.currentTarget;
        const rect = progressBar.getBoundingClientRect();
        const clickX = e.clientX - rect.left;
        const progressWidth = rect.width;
        const clickPercentage = clickX / progressWidth;
        const newTime = clickPercentage * duration;

        audioRef.current.currentTime = newTime;
        setCurrentTime(newTime);
    };

    const handleVolumeChange = (e) => {
        const newVolume = parseFloat(e.target.value);
        setVolume(newVolume);
        if (audioRef.current) {
            audioRef.current.volume = newVolume;
        }
    };

    const formatTime = (seconds) => {
        if (!seconds || seconds === 0) return "00:00";
        const mins = Math.floor(seconds / 60);
        const secs = Math.floor(seconds % 60);
        return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    };

    const formatTimerLarge = (seconds) => {
        if (!seconds || seconds === 0) return "00:00";
        const mins = Math.floor(seconds / 60);
        const secs = seconds % 60;
        return `${mins}:${secs.toString().padStart(2, '0')}`;
    };

    const getAnsweredCount = () => {
        return Object.keys(userAnswers).filter(key => userAnswers[key]?.trim()).length;
    };

    const getTotalQuestions = () => {
        return questions ? questions.length : 0;
    };

    const groupQuestionsByTypeAndInstructions = (questions, currentAudio) => {
        const groups = {};

        questions.forEach(question => {
            if (question.audioId === currentAudio?.id) {
                const key = `${question.questionType}_${question.audioId}_${question.questionSetInstructions || 'default'}`;

                if (!groups[key]) {
                    groups[key] = {
                        questionType: question.questionType,
                        audioId: question.audioId,
                        questions: [],
                        instructions: question.questionSetInstructions || getDefaultInstructionsByQuestionType(question.questionType)
                    };
                }

                groups[key].questions.push(question);
            }
        });

        return Object.values(groups);
    };

    const getDefaultInstructionsByQuestionType = (questionType) => {
        const instructionsMap = {
            'MCQ': 'Choose the correct answer A, B, C or D.',
            'MATCHING': 'Choose the correct headings for each section from the list of headings below.',
            'FILL_IN_THE_BLANK': 'Complete the sentences below. Choose NO MORE THAN TWO WORDS from the passage.',
            'TRUE_FALSE_NOT_GIVEN': 'Do the following statements agree with the information given in the passage?',
            'SHORT_ANSWER': 'Answer the questions below. Choose NO MORE THAN THREE WORDS from the passage.',
        };

        return instructionsMap[questionType] || 'Answer the following questions based on the passage.';
    };

    return (
        <div className="test-detail-page" style={{width: '100vw', maxWidth: 'none', margin: 0, padding: 0}}>
            <div className="main-content" style={{width: '100%', maxWidth: 'none', margin: 0}}>
                <div className="test-main-container" style={{width: '100%', maxWidth: 'none', margin: 0}}>
                    <h1 className="test-title">{test?.testName || 'IELTS Listening Test'}</h1>

                    <div className="top-timer-mobile">
                        <div className="timer-label">Thời gian còn lại:</div>
                        <div className="timer-value">{formatTimerLarge(timer)}</div>
                    </div>

                    {/* Recording Tabs - giống như passage tabs */}
                    <div className="recording-tabs">
                        {audioList && audioList.length > 0 ? audioList.map((audio, index) => (
                            <button
                                key={audio.id || index}
                                className={`recording-tab ${currentAudioIndex === index ? 'active' : ''}`}
                                onClick={() => setCurrentAudioIndex(index)}
                            >
                                Recording {index + 1}
                            </button>
                        )) : (
                            <div className="recording-tab active">
                                Recording 1
                            </div>
                        )}
                    </div>

                    {/* Main content container - 3 columns như Reading */}
                    <div className="unified-content-container" style={{width: '100%', maxWidth: 'none', margin: 0}}>
                        {/* Left: Audio section (thay cho passage content) */}
                        <div className="content-section">
                            <h2 className="section-title">Audio Player</h2>

                            {/* Audio status */}
                            <div className="audio-status">
                                {loadingAudio && (
                                    <div className="status-message loading">
                                        <span>⏳</span> Loading audio...
                                    </div>
                                )}

                                {audioError && (
                                    <div className="status-message error">
                                        <span>❌</span> {audioError}
                                        <button
                                            className="retry-btn"
                                            onClick={() => {
                                                setAudioError(null);
                                                if (audioRef.current && currentAudio) {
                                                    const audioSrc = getValidAudioSource(currentAudio);
                                                    if (audioSrc) {
                                                        audioRef.current.src = audioSrc;
                                                        audioRef.current.load();
                                                    }
                                                }
                                            }}
                                        >
                                            Retry
                                        </button>
                                    </div>
                                )}

                                {audioReady && !loadingAudio && !audioError && (
                                    <div className="status-message ready">
                                        <span>✅</span> Audio ready
                                    </div>
                                )}
                            </div>

                            {/* Audio controls */}
                            <div className="audio-controls">
                                <button
                                    className={`play-btn ${!audioReady ? 'disabled' : ''}`}
                                    onClick={togglePlay}
                                    disabled={loadingAudio || !!audioError}
                                >
                                    {loadingAudio ? '⏳' : isPlaying ? '⏸️' : '▶️'}
                                </button>

                                <div className="progress-container">
                                    <div className="progress-bar" onClick={handleProgressClick}>
                                        <div
                                            className="progress-fill"
                                            style={{width: duration ? `${(currentTime / duration) * 100}%` : '0%'}}
                                        />
                                    </div>
                                    <div className="time-display">
                                        {formatTime(currentTime)} / {formatTime(duration)}
                                    </div>
                                </div>

                                <div className="volume-controls">
                                    <span>🔊</span>
                                    <input
                                        type="range"
                                        min="0"
                                        max="1"
                                        step="0.1"
                                        value={volume}
                                        onChange={handleVolumeChange}
                                        className="volume-slider"
                                    />
                                </div>
                            </div>

                            {/* Audio info */}
                            {currentAudio && (
                                <div className="audio-info">
                                    <h3>{currentAudio.title || `Recording ${currentAudioIndex + 1}`}</h3>
                                    <p className="audio-description">
                                        {currentAudio.section || 'IELTS Listening Audio'}
                                    </p>
                                    {currentAudio.transcript && (
                                        <details className="transcript">
                                            <summary>Show Transcript (for practice only)</summary>
                                            <div className="transcript-content">
                                                {currentAudio.transcript}
                                            </div>
                                        </details>
                                    )}
                                </div>
                            )}
                        </div>

                        {/* Middle: Questions section */}
                        <div className="questions-section">
                            <h2 className="section-title">Questions</h2>
                            {groupQuestionsByTypeAndInstructions(questions, currentAudio).map((group, groupIndex) => (
                                <div key={`group-${groupIndex}`} className="question-group">
                                    <div className="question-type-header">
                                        <h3>{group.questionType.replace(/_/g, ' ')}</h3>
                                        <span className="question-count">
                                            Questions {group.questions[0]?.orderInTest} - {group.questions[group.questions.length - 1]?.orderInTest}
                                        </span>
                                    </div>

                                    {group.instructions && (
                                        <div className="instructions">
                                            <p>{group.instructions}</p>
                                        </div>
                                    )}

                                    {/* Context Section - tables, forms, etc. */}
                                    {processQuestions.find(g => g.audioId === currentAudio?.id && g.requiresContext) && (
                                        <div className="context-section">
                                            {processQuestions
                                                .filter(g => g.audioId === currentAudio?.id && g.requiresContext)
                                                .map((contextGroup, idx) => (
                                                    <div key={idx}>
                                                        {contextGroup.subType === 'TABLE_COMPLETION_JSON' ? (
                                                            renderJSONTable(contextGroup.context, contextGroup)
                                                        ) : contextGroup.subType === 'TABLE_COMPLETION' ? (
                                                            renderMarkdownTable(contextGroup.context, contextGroup)
                                                        ) : (
                                                            renderContextWithInputs(contextGroup.context, contextGroup)
                                                        )}
                                                    </div>
                                                ))}
                                        </div>
                                    )}

                                    {/* Regular Questions */}
                                    <div className="questions-list">
                                        {group.questions
                                            .sort((a, b) => a.orderInTest - b.orderInTest)
                                            .map((question, index) => (
                                                <div key={question.id} className="question-item">
                                                    <div className="question-number" data-order-in-test={question.orderInTest}>
                                                        {question.orderInTest}
                                                    </div>
                                                    <div className="question-content">
                                                        {question.questionText && (
                                                            <p className="question-text">{question.questionText}</p>
                                                        )}
                                                        {renderQuestionInput(question, group.questionType)}
                                                    </div>
                                                </div>
                                            ))}
                                    </div>
                                </div>
                            ))}

                            {(!questions || questions.filter(q => q.audioId === currentAudio?.id).length === 0) && (
                                <div className="no-questions">
                                    <p>No questions available for this recording.</p>
                                </div>
                            )}
                        </div>

                        {/* Right: Sidebar - giống Reading */}
                        <div className="test-sidebar">
                            <div className="sidebar-timer">
                                <h3>Thời gian còn lại:</h3>
                                <div className="time-display">{formatTimerLarge(timer)}</div>
                            </div>

                            <button
                                className="submit-button"
                                onClick={onSubmit}
                                disabled={submitting}
                            >
                                {submitting ? 'ĐANG NỘP...' : 'NỘP BÀI'}
                            </button>

                            <div className="progress-summary">
                                <div className="progress-text">
                                    Đã hoàn thành: {getAnsweredCount()} / {getTotalQuestions()}
                                </div>
                                <div className="progress-bar-summary">
                                    <div
                                        className="progress-fill-summary"
                                        style={{ width: `${getTotalQuestions() > 0 ? (getAnsweredCount() / getTotalQuestions()) * 100 : 0}%` }}
                                    />
                                </div>
                            </div>

                            <div className="review-note">
                                <strong>Chú ý:</strong> bạn có thể click vào số thứ tự câu hỏi trong bài để đánh dấu review
                            </div>

                            {/* Navigation cho từng recording */}
                            {audioList && audioList.map((audio, audioIndex) => {
                                let audioQuestions = questions.filter(q => (q.audioId || q.audio_id) === audio.id);

                                if (audioQuestions.length === 0) {
                                    const questionsPerAudio = Math.ceil(questions.length / audioList.length);
                                    const startIndex = audioIndex * questionsPerAudio;
                                    const endIndex = startIndex + questionsPerAudio;
                                    audioQuestions = questions.slice(startIndex, endIndex);
                                }

                                if (audioQuestions.length === 0) return null;

                                return (
                                    <div key={audioIndex} className="recording-questions">
                                        <h3>Recording {audioIndex + 1}</h3>
                                        <div className="question-buttons">
                                            {audioQuestions
                                                .sort((a, b) => (a.orderInTest || a.order_in_test || 0) - (b.orderInTest || b.order_in_test || 0))
                                                .map(question => {
                                                    const questionId = question.id || question.question_id;
                                                    const questionNumber = question.orderInTest || question.order_in_test || question.questionNumber;
                                                    const isAnswered = userAnswers[questionId]?.trim();

                                                    return (
                                                        <button
                                                            key={questionId}
                                                            className={`question-button ${isAnswered ? 'answered' : ''}`}
                                                            onClick={() => {
                                                                setCurrentAudioIndex(audioIndex);
                                                                setTimeout(() => {
                                                                    const questionElement = document.querySelector(`[data-order-in-test="${questionNumber}"]`);
                                                                    if (questionElement) {
                                                                        questionElement.scrollIntoView({behavior: 'smooth'});
                                                                    }
                                                                }, 100);
                                                            }}
                                                        >
                                                            {questionNumber}
                                                        </button>
                                                    );
                                                })}
                                        </div>
                                    </div>
                                );
                            })}
                        </div>
                    </div>
                </div>
            </div>

            {/* Hidden Audio Element */}
            <audio
                ref={audioRef}
                volume={volume}
                preload="metadata"
                crossOrigin="anonymous"
            />
        </div>
    );
};

export default ListeningTestDisplay;