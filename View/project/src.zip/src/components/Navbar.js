import React, { useState, useEffect } from 'react';
import './Navbar.css';
import { Link, useNavigate } from 'react-router-dom';
import { getUserFromToken, isTokenExpired, canCreateExam } from '../utlis/authUtils';

function Navbar() {
    const navigate = useNavigate();
    const [user, setUser] = useState(null);

    useEffect(() => {
        const updateUserInfo = () => {
            console.log("🔄 Navbar: Updating user info...");

            if (isTokenExpired()) {
                console.log("❌ Token expired, clearing user");
                setUser(null);
                localStorage.removeItem('token');
            } else {
                const currentUser = getUserFromToken();
                console.log("👤 Navbar: Current user from token:", currentUser);
                console.log("🎭 Navbar: User role:", currentUser?.role);
                setUser(currentUser);
            }
        };

        // Initial load
        updateUserInfo();

        // Listen for storage changes (login/logout)
        const handleStorageChange = (e) => {
            console.log("📢 Navbar: Storage change event received:", e);
            updateUserInfo();
        };

        // Listen for custom user update events
        const handleUserUpdate = (e) => {
            console.log("📢 Navbar: User update event received:", e);
            updateUserInfo();
        };

        window.addEventListener('storage', handleStorageChange);
        window.addEventListener('userUpdated', handleUserUpdate);

        return () => {
            window.removeEventListener('storage', handleStorageChange);
            window.removeEventListener('userUpdated', handleUserUpdate);
        };
    }, []);

    const handleLogout = () => {
        console.log('🚪 Đang đăng xuất...');
        localStorage.removeItem('token');
        setUser(null);
        window.dispatchEvent(new Event('storage'));
        window.location.href = '/login';
    };

    // Debug logging for render
    console.log("🎨 Navbar render - User:", user);
    console.log("🎭 Navbar render - Role:", user?.role);

    const showCreateExam = user && (user.role === 'TEACHER' || user.role === 'ROLE_TEACHER' || user.role === 'ADMIN' || user.role === 'ROLE_ADMIN');
    const showManageSection = user && (user.role === 'TEACHER' || user.role === 'ROLE_TEACHER' || user.role === 'ADMIN' || user.role === 'ROLE_ADMIN');

    console.log("🔧 Navbar render - showCreateExam:", showCreateExam);
    console.log("🔧 Navbar render - showManageSection:", showManageSection);

    return (
        <nav className="navbar">
            <div className="logo">
            </div>

            <ul className="nav-links">
                <li><Link to="/">Trang chủ</Link></li>
                <li><Link to="/program">Chương trình học</Link></li>
                <li><Link to="/online-exam">Đề thi online</Link></li>

                {/* ✅ FLASHCARDS - CHO TẤT CẢ USER */}
                <li className="dropdown">
                    <span className="dropbtn">📚 Flashcards</span>
                    <div className="dropdown-content">
                        <Link to="/flashcards">🏠 Trang chủ Flashcards</Link>
                        {user && (
                            <>
                                <Link to="/flashcards/study">🎯 Học hôm nay</Link>
                                <Link to="/flashcards/sets">📑 Bộ thẻ từ vựng</Link>
                                <Link to="/flashcards/statistics">📊 Thống kê của tôi</Link>
                            </>
                        )}
                        {showCreateExam && (
                            <Link to="/flashcards/create">➕ Tạo flashcard mới</Link>
                        )}
                    </div>
                </li>

                {/* ✅ TEACHER/ADMIN ONLY - Create Exam */}
                {showCreateExam && (
                    <li><Link to="/create-exam">Tạo bài thi</Link></li>
                )}

                {/* ✅ TEACHER/ADMIN ONLY - Management */}
                {showManageSection && (
                    <li className="dropdown">
                        <span className="dropbtn">Quản lý</span>
                        <div className="dropdown-content">
                            <Link to="/my-tests">Bài thi của tôi</Link>
                            {user && (user.role === 'ADMIN' || user.role === 'ROLE_ADMIN') && (
                                <Link to="/admin/all-tests">Tất cả bài thi</Link>
                            )}
                            <Link to="/grade-submissions">Chấm bài</Link>
                        </div>
                    </li>
                )}
            </ul>

            <div className="actions">
                {/* ✅ USER INFO SECTION */}
                {user && (
                    <div className="user-info">
                        <span className="user-greeting">
                            Xin chào, {user.fullName || user.email}
                        </span>
                        <span className={`role-badge role-${user.role?.replace('ROLE_', '').toLowerCase()}`}>
                            {user.role === 'TEACHER' || user.role === 'ROLE_TEACHER' ? '👨‍🏫 Teacher' :
                                user.role === 'ADMIN' || user.role === 'ROLE_ADMIN' ? '👑 Admin' :
                                    '🎓 Student'}
                        </span>
                    </div>
                )}

                {/* ✅ ACTION BUTTONS */}
                <div className="action-buttons">

                    {/* ✅ USER DROPDOWN MENU */}
                    {user && (
                        <div className="user-dropdown">
                            <button className="user-avatar-btn">
                                <div className="avatar-circle">
                                    <span>{(user.fullName || user.email).charAt(0).toUpperCase()}</span>
                                </div>
                                <span className="dropdown-arrow">▼</span>
                            </button>

                            <div className="user-dropdown-content">
                                {/* Thông báo */}
                                <div className="dropdown-section">
                                    <div className="dropdown-header">Thông báo</div>
                                    <div className="notification-item">
                                        <span className="notification-text">Bạn chưa có thông báo mới.</span>
                                        <Link to="/notifications" className="view-all-link">Xem tất cả &gt;&gt;</Link>
                                    </div>
                                </div>

                                <div className="dropdown-divider"></div>

                                {/* Menu items */}
                                <div className="dropdown-section">
                                    <Link to="/profile" className="dropdown-item">
                                        <span className="dropdown-icon">👤</span>
                                        Trang cá nhân
                                    </Link>

                                    <Link to="/learning-history" className="dropdown-item">
                                        <span className="dropdown-icon">📚</span>
                                        Lịch học của tôi
                                    </Link>

                                    {/* ✅ FLASHCARD QUICK ACCESS */}
                                    <Link to="/flashcards/study" className="dropdown-item flashcard-item">
                                        <span className="dropdown-icon">🎯</span>
                                        Học Flashcards hôm nay
                                    </Link>

                                    <button onClick={handleLogout} className="dropdown-item logout-item">
                                        <span className="dropdown-icon">🚪</span>
                                        Đăng xuất
                                    </button>
                                </div>
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </nav>
    );
}

export default Navbar;