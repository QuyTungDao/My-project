package tungdao.com.project1.entity;

public enum TestScoreMappingType {
    LISTENING,
    READING
}
