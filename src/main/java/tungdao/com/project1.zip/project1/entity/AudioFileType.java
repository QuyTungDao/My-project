package tungdao.com.project1.entity;

public enum AudioFileType {
    MP3,
    WAV,
    OGG,
    M4A
}
