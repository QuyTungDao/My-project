package tungdao.com.project1.entity;

public enum SkillType {
    WRITING,
    SPEAKING
}
