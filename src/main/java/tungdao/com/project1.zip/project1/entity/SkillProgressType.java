package tungdao.com.project1.entity;

public enum SkillProgressType {
    LISTENING,
    READING,
    WRITING,
    SPEAKING,
    OVERALL
}
