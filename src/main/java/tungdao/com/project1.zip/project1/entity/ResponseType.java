package tungdao.com.project1.entity;

public enum ResponseType {
        TEXT,
        AUDIO,
        FILE
}
