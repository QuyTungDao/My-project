package tungdao.com.project1.entity;

public enum UserRole {
    STUDENT,
    TEACHER,
    ADMIN
}
