package tungdao.com.project1.entity;

public enum ListeningSection {
    SECTION1,
    SECTION2,
    SECTION3,
    SECTION4
}
