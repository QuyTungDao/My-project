package tungdao.com.project1.dto;

import lombok.Data;

@Data
public class UserStatsDTO {
    private Object testStats;
    private Object flashcardStats;
    private Object generalStats;
}